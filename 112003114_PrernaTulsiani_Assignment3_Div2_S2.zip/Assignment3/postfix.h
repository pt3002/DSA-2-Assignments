int isOperand(char ch);

int Precedence_check(char ch);

int infixToPostfix(char* exp);

